#include "UserFlowController.h"
#include <iostream>
int main()
{
	UserFlowController userFlowController;
	userFlowController.ShowMainMenu();
}